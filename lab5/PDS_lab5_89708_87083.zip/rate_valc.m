H=size(R_I3);
s=0;
for i=1:H(1)
   s=s + sum(R_I3(i,:)==1);
end